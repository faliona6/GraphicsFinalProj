
Fiona Soetrisno, CPE 471 - Program 3

Multimesh model and no normals - bunny_noNormals.obj
