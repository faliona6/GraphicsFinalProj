
Fiona Soetrisno, CPE 471 - Program 4

Camera
I wanted to have a third person camera that focused on the main character. clicking and dragging the mouse rotates the camera around Link, and using WASD moves link around. You can also scroll to zoom in or out towards link.

If you click N, link will only move along an xz plane, which will be more like how it will feel like after I add collision detection and he is always on the floor.

Notes
I added a water vert shader that distorts the vert pos and calculates new normals

Trees are randomly placed

Janky bunny that I 3d modeled now has textures and blinks! Not T-posing anymore

Skybox rotates